from django.conf.urls import url

from django.urls import path

from . import views


app_name = 'SMS'

urlpatterns = [
            path('', views.index, name='index'),
			path('index',views.index, name='index'),
			path('index2',views.index2, name='index2'),
            path("about", views.about, name='about'),
            path("contact", views.contact, name='contact'),
            url("registration", views.register,name = 'registration'),
            url("user_login", views.user_login,name = 'user_login'),
			
			
      
            
         ]

