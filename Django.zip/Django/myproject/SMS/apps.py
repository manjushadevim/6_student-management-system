from django.apps import AppConfig


class SMSConfig(AppConfig):
    name = 'SMS'
