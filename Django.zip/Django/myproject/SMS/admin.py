from django.contrib import admin
from SMS.models import UserProfileInfo, User

admin.site.register(UserProfileInfo)

